# Deep Learning Projects

Two independent Deep Learning projects:

1. Bengaluru House Price Prediction - Regression
2. Customer Churn Prediction - Binary Classification

Each folder is self-contained with its dataset, notebook, preprocessing metadata, trained PyTorch model, README and requirements.
