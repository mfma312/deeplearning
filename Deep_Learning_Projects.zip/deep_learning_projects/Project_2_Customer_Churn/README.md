# Customer Churn - Deep Learning

A PyTorch neural-network binary classification project for predicting customer churn.

Run `Customer_Churn_Deep_Learning.ipynb` from top to bottom.
