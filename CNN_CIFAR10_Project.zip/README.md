# CNN Image Classification Project

Dataset: CIFAR-10 (downloaded automatically by Keras when the notebook is run).

## Project contents
- `CNN_CIFAR10_Project.ipynb` — complete CNN project.
- `requirements.txt` — required Python packages.
- `README.md` — instructions.

## What the notebook does
1. Loads CIFAR-10.
2. Explores the image data.
3. Normalizes images.
4. Builds a CNN using TensorFlow/Keras.
5. Trains the model.
6. Evaluates accuracy and loss.
7. Shows a confusion matrix.
8. Displays sample predictions.

## Run
Install dependencies:
`pip install -r requirements.txt`

Then open the notebook with Jupyter Notebook/JupyterLab.
